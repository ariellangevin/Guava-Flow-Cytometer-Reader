%% Comprehensive FCS Read 2015-10-18_at_05-15-40pm

clc, close

%[FSC,SSC,GRN,YEL,RED_B,RED_R,RED_R_Area,RED_R_Width,Time]=dataFCS(GroupName,Samples,Replicates);

[FSC,SSC,GRN,YEL,RED_B,RED_R,RED_R_Area,RED_R_Width,Time]=dataFCS('2015-10-18_at_05-15-40pm',32,1);

% Samples
% A: JW0451 dKr
% B: rfp/JW0451 dKr
% C: sfgfp/JW0451 dKr
% D: rfp/JW0451 dKr & sfgfp/JW0451 dKr co-culture
% E: MG1655
% F: rfp/MG1655
% G: sfgfp/MG1655
% H: rfp/MG1655 & sfgfp/MG1655 co-culture

% 1: 0 �M
% 2: 10 �M
% 3: 100 �M
% 4: 1000 �M



%% Green

% A1=1-3

[N1,XA1]=hist(GRN(:,1),100);
[N2,X2]=hist(GRN(:,2),100);
[N3,X3]=hist(GRN(:,3),100);

N=[N1' N2' N3'];
NavgA1=mean(N');
Sn=std(N');

ULA1=NavgA1+1.66*Sn;
LLA1=NavgA1-1.66*Sn;

figure(1)
subplot(3,4,1)
title('A1')
plot(XA1,NavgA1,'k-',XA1,ULA1,'k--',XA1,LLA1,'k--')

% A2=4-6

[N1,XA2]=hist(GRN(:,4),100);
[N2,X2]=hist(GRN(:,5),100);
[N3,X3]=hist(GRN(:,6),100);

N=[N1' N2' N3'];
NavgA2=mean(N');
Sn=std(N');

ULA2=NavgA2+1.66*Sn;
LLA2=NavgA2-1.66*Sn;

figure(1)
subplot(3,4,2)
title('A2')
plot(XA2,NavgA2,'k-',XA2,ULA2,'k--',XA2,LLA2,'k--')
axis([])

% A3=7-9

[N1,XA3]=hist(GRN(:,7),100);
[N2,X2]=hist(GRN(:,8),100);
[N3,X3]=hist(GRN(:,9),100);

N=[N1' N2' N3'];
NavgA3=mean(N');
Sn=std(N');

ULA3=NavgA3+1.66*Sn;
LLA3=NavgA3-1.66*Sn;

figure(1)
subplot(3,4,3)
title('A3')
plot(XA3,NavgA3,'k-',XA3,ULA3,'k--',XA3,LLA3,'k--')

% A4=10-12

[N1,XA4]=hist(GRN(:,10),100);
[N2,X2]=hist(GRN(:,11),100);
[N3,X3]=hist(GRN(:,12),100);

N=[N1' N2' N3'];
NavgA4=mean(N');
Sn=std(N');

ULA4=NavgA4+1.66*Sn;
LLA4=NavgA4-1.66*Sn;

figure(1)
subplot(3,4,4)
title('A4')
plot(XA4,NavgA4,'k-',XA4,ULA4,'k--',XA4,LLA4,'k--')

figure(2)
subplot(1,3,1)
semilogx(XA1,NavgA1,'k-',XA2,NavgA2,'r-',XA3,NavgA3,'b-',XA4,NavgA4,'g-',XA1,ULA1,'k--',XA1,LLA1,'k--')
hold on
semilogx(XA2,ULA2,'r--',XA2,LLA2,'r--')
semilogx(XA3,ULA3,'b--',XA3,LLA3,'b--')
semilogx(XA4,ULA4,'g--',XA4,LLA4,'g--')
hold off
title('MG1655')
legend('0�M','10�M','100�M','1000�M')
axis([10 10^5 0 500])

figure(3)
subplot(1,3,1)
semilogx(XA1,NavgA1,'k-',XA2,NavgA2,'r-',XA3,NavgA3,'b-',XA4,NavgA4,'g-')
title('MG1655')
legend('0�M IPTG','10�M IPTG','100�M IPTG','1000�M IPTG')
axis([100 10^5 0 500])
xlabel('Log - Green Fluoresence (AU)')
ylabel('Count')

% B1=13-15

[N1,XB1]=hist(GRN(:,13),100);
[N2,X2]=hist(GRN(:,14),100);
[N3,X3]=hist(GRN(:,15),100);

N=[N1' N2' N3'];
NavgB1=mean(N');
Sn=std(N');

ULB1=NavgB1+1.66*Sn;
LLB1=NavgB1-1.66*Sn;

figure(1)
subplot(3,4,5)
plot(XB1,NavgB1,'k-',XB1,ULB1,'k--',XB1,LLB1,'k--')
title('B1')

% B2=16-18

[N1,XB2]=hist(GRN(:,16),100);
[N2,X2]=hist(GRN(:,17),100);
[N3,X3]=hist(GRN(:,18),100);

N=[N1' N2' N3'];
NavgB2=mean(N');
Sn=std(N');

ULB2=NavgB2+1.66*Sn;
LLB2=NavgB2-1.66*Sn;

figure(1)
subplot(3,4,6)
title('B2')
plot(XB2,NavgB2,'k-',XB2,ULB2,'k--',XB2,LLB2,'k--')
axis([])

% B3=19-21

[N1,XB3]=hist(GRN(:,19),100);
[N2,X2]=hist(GRN(:,20),100);
[N3,X3]=hist(GRN(:,21),100);

N=[N1' N2' N3'];
NavgB3=mean(N');
Sn=std(N');

ULB3=NavgB3+1.66*Sn;
LLB3=NavgB3-1.66*Sn;

figure(1)
subplot(3,4,7)
title('B3')
plot(XB3,NavgB3,'k-',XB3,ULB3,'k--',XB3,LLB3,'k--')

% B4=22-24

[N1,XB4]=hist(GRN(:,22),100);
[N2,X2]=hist(GRN(:,23),100);
[N3,X3]=hist(GRN(:,24),100);

N=[N1' N2' N3'];
NavgB4=mean(N');
Sn=std(N');

ULB4=NavgB4+1.66*Sn;
LLB4=NavgB4-1.66*Sn;

figure(1)
subplot(3,4,8)
title('B4')
plot(XB4,NavgB4,'k-',XB4,ULB4,'k--',XB4,LLB4,'k--')


figure(2)
subplot(1,3,2)
semilogx(XB1,NavgB1,'k-',XB2,NavgB2,'r-',XB3,NavgB3,'b-',XB4,NavgB4,'g-',XB1,ULB1,'k--',XB1,LLB1,'k--')
hold on
semilogx(XB2,ULB2,'r--',XB2,LLB2,'r--')
semilogx(XB3,ULB3,'b--',XB3,LLB3,'b--')
semilogx(XB4,ULB4,'g--',XB4,LLB4,'g--')
hold off
title('pBbA5k-rfp/MG1655')
legend('0�M','10�M','100�M','1000�M')
axis([10 10^5 0 500])

figure(3)
subplot(1,3,2)
semilogx(XB1,NavgB1,'k-',XB2,NavgB2,'r-',XB3,NavgB3,'b-',XB4,NavgB4,'g-')
title('pBbA5k-rfp/MG1655')
legend('0�M IPTG','10�M IPTG','100�M IPTG','1000�M IPTG')
axis([100 10^5 0 500])
xlabel('Log - Green Fluoresence (AU)')
ylabel('Count')

% C1=25-27

[N1,XC1]=hist(GRN(:,25),100);
[N2,X2]=hist(GRN(:,26),100);
[N3,X3]=hist(GRN(:,27),100);

N=[N1' N2' N3'];
NavgC1=mean(N');
Sn=std(N');

ULC1=NavgC1+1.66*Sn;
LLC1=NavgC1-1.66*Sn;

figure(1)
subplot(3,4,9)
plot(XC1,NavgC1,'k-',XC1,ULC1,'k--',XC1,LLC1,'k--')
title('C1')

% C2=28-30

[N1,XC2]=hist(GRN(:,28),100);
[N2,X2]=hist(GRN(:,29),100);
[N3,X3]=hist(GRN(:,30),100);

N=[N1' N2' N3'];
NavgC2=mean(N');
Sn=std(N');

ULC2=NavgC2+1.66*Sn;
LLC2=NavgC2-1.66*Sn;

figure(1)
subplot(3,4,10)
title('C2')
plot(XC2,NavgC2,'k-',XC2,ULC2,'k--',XC2,LLC2,'k--')
axis([])

% C3=31-33

[N1,XC3]=hist(GRN(:,31),100);
[N2,X2]=hist(GRN(:,32),100);
[N3,X3]=hist(GRN(:,33),100);

N=[N1' N2' N3'];
NavgC3=mean(N');
Sn=std(N');

ULC3=NavgC3+1.66*Sn;
LLC3=NavgC3-1.66*Sn;

figure(1)
subplot(3,4,11)
title('C3')
plot(XC3,NavgC3,'k-',XC3,ULC3,'k--',XC3,LLC3,'k--')

% C4=34-36

[N1,XC4]=hist(GRN(:,34),100);
[N2,X2]=hist(GRN(:,35),100);
[N3,X3]=hist(GRN(:,36),100);

N=[N1' N2' N3'];
NavgC4=mean(N');
Sn=std(N');

ULC4=NavgC4+1.66*Sn;
LLC4=NavgC4-1.66*Sn;

figure(1)
subplot(3,4,12)
title('C4')
plot(XC4,NavgC4,'k-',XC4,ULC4,'k--',XC4,LLC4,'k--')

figure(2)
subplot(1,3,3)
semilogx(XC1,NavgC1,'k-',XC2,NavgC2,'r-',XC3,NavgC3,'b-',XC4,NavgC4,'g-',XC1,ULC1,'k--',XC1,LLC1,'k--')
hold on
semilogx(XC2,ULC2,'r--',XC2,LLC2,'r--')
semilogx(XC3,ULC3,'b--',XC3,LLC3,'b--')
semilogx(XC4,ULC4,'g--',XC4,LLC4,'g--')
hold off
title('pBbA5k-sfgfp/MG1655')
legend('0�M','10�M','100�M','1000�M')
axis([10 10^5 0 500])

figure(3)
subplot(1,3,3)
semilogx(XC1,NavgC1,'k-',XC2,NavgC2,'r-',XC3,NavgC3,'b-',XC4,NavgC4,'g-')
title('pBbA5k-sfgfp/MG1655')
legend('0�M IPTG','10�M IPTG','100�M IPTG','1000�M IPTG')
axis([100 10^5 0 500])
xlabel('Log - Green Fluoresence (AU)')
ylabel('Count')

%% Red

% A1=1-3

[N1,XA1]=hist(RED_B(:,1),100);
[N2,X2]=hist(RED_B(:,2),100);
[N3,X3]=hist(RED_B(:,3),100);

N=[N1' N2' N3'];
NavgA1=mean(N');
Sn=std(N');

ULA1=NavgA1+1.66*Sn;
LLA1=NavgA1-1.66*Sn;

figure(1)
subplot(3,4,1)
title('A1')
plot(XA1,NavgA1,'k-',XA1,ULA1,'k--',XA1,LLA1,'k--')

% A2=4-6

[N1,XA2]=hist(RED_B(:,4),100);
[N2,X2]=hist(RED_B(:,5),100);
[N3,X3]=hist(RED_B(:,6),100);

N=[N1' N2' N3'];
NavgA2=mean(N');
Sn=std(N');

ULA2=NavgA2+1.66*Sn;
LLA2=NavgA2-1.66*Sn;

figure(1)
subplot(3,4,2)
title('A2')
plot(XA2,NavgA2,'k-',XA2,ULA2,'k--',XA2,LLA2,'k--')
axis([])

% A3=7-9

[N1,XA3]=hist(RED_B(:,7),100);
[N2,X2]=hist(RED_B(:,8),100);
[N3,X3]=hist(RED_B(:,9),100);

N=[N1' N2' N3'];
NavgA3=mean(N');
Sn=std(N');

ULA3=NavgA3+1.66*Sn;
LLA3=NavgA3-1.66*Sn;

figure(1)
subplot(3,4,3)
title('A3')
plot(XA3,NavgA3,'k-',XA3,ULA3,'k--',XA3,LLA3,'k--')

% A4=10-12

[N1,XA4]=hist(RED_B(:,10),100);
[N2,X2]=hist(RED_B(:,11),100);
[N3,X3]=hist(RED_B(:,12),100);

N=[N1' N2' N3'];
NavgA4=mean(N');
Sn=std(N');

ULA4=NavgA4+1.66*Sn;
LLA4=NavgA4-1.66*Sn;

figure(1)
subplot(3,4,4)
title('A4')
plot(XA4,NavgA4,'k-',XA4,ULA4,'k--',XA4,LLA4,'k--')

figure(2)
subplot(1,3,1)
semilogx(XA1,NavgA1,'k-',XA2,NavgA2,'r-',XA3,NavgA3,'b-',XA4,NavgA4,'g-',XA1,ULA1,'k--',XA1,LLA1,'k--')
hold on
semilogx(XA2,ULA2,'r--',XA2,LLA2,'r--')
semilogx(XA3,ULA3,'b--',XA3,LLA3,'b--')
semilogx(XA4,ULA4,'g--',XA4,LLA4,'g--')
hold off
title('MG1655')
legend('0�M','10�M','100�M','1000�M')
axis([10 10^5 0 500])

figure(3)
subplot(1,3,1)
semilogx(XA1,NavgA1,'k-',XA2,NavgA2,'r-',XA3,NavgA3,'b-',XA4,NavgA4,'g-')
title('MG1655')
legend('0�M IPTG','10�M IPTG','100�M IPTG','1000�M IPTG')
axis([1 10^5 0 1000])
xlabel('Log - Red Fluoresence (AU)')
ylabel('Count')

% B1=13-15

[N1,XB1]=hist(RED_B(:,13),100);
[N2,X2]=hist(RED_B(:,14),100);
[N3,X3]=hist(RED_B(:,15),100);

N=[N1' N2' N3'];
NavgB1=mean(N');
Sn=std(N');

ULB1=NavgB1+1.66*Sn;
LLB1=NavgB1-1.66*Sn;

figure(1)
subplot(3,4,5)
plot(XB1,NavgB1,'k-',XB1,ULB1,'k--',XB1,LLB1,'k--')
title('B1')

% B2=16-18

[N1,XB2]=hist(RED_B(:,16),100);
[N2,X2]=hist(RED_B(:,17),100);
[N3,X3]=hist(RED_B(:,18),100);

N=[N1' N2' N3'];
NavgB2=mean(N');
Sn=std(N');

ULB2=NavgB2+1.66*Sn;
LLB2=NavgB2-1.66*Sn;

figure(1)
subplot(3,4,6)
title('B2')
plot(XB2,NavgB2,'k-',XB2,ULB2,'k--',XB2,LLB2,'k--')
axis([])

% B3=19-21

[N1,XB3]=hist(RED_B(:,19),100);
[N2,X2]=hist(RED_B(:,20),100);
[N3,X3]=hist(RED_B(:,21),100);

N=[N1' N2' N3'];
NavgB3=mean(N');
Sn=std(N');

ULB3=NavgB3+1.66*Sn;
LLB3=NavgB3-1.66*Sn;

figure(1)
subplot(3,4,7)
title('B3')
plot(XB3,NavgB3,'k-',XB3,ULB3,'k--',XB3,LLB3,'k--')

% B4=22-24

[N1,XB4]=hist(RED_B(:,22),100);
[N2,X2]=hist(RED_B(:,23),100);
[N3,X3]=hist(RED_B(:,24),100);

N=[N1' N2' N3'];
NavgB4=mean(N');
Sn=std(N');

ULB4=NavgB4+1.66*Sn;
LLB4=NavgB4-1.66*Sn;

figure(1)
subplot(3,4,8)
title('B4')
plot(XB4,NavgB4,'k-',XB4,ULB4,'k--',XB4,LLB4,'k--')


figure(2)
subplot(1,3,2)
semilogx(XB1,NavgB1,'k-',XB2,NavgB2,'r-',XB3,NavgB3,'b-',XB4,NavgB4,'g-',XB1,ULB1,'k--',XB1,LLB1,'k--')
hold on
semilogx(XB2,ULB2,'r--',XB2,LLB2,'r--')
semilogx(XB3,ULB3,'b--',XB3,LLB3,'b--')
semilogx(XB4,ULB4,'g--',XB4,LLB4,'g--')
hold off
title('pBbA5k-rfp/MG1655')
legend('0�M','10�M','100�M','1000�M')
axis([10 10^5 0 500])

figure(3)
subplot(1,3,2)
semilogx(XB1,NavgB1,'k-',XB2,NavgB2,'r-',XB3,NavgB3,'b-',XB4,NavgB4,'g-')
title('pBbA5k-rfp/MG1655')
legend('0�M IPTG','10�M IPTG','100�M IPTG','1000�M IPTG')
axis([1 10^5 0 1000])
xlabel('Log - Red Fluoresence (AU)')
ylabel('Count')

% C1=25-27

[N1,XC1]=hist(RED_B(:,25),100);
[N2,X2]=hist(RED_B(:,26),100);
[N3,X3]=hist(RED_B(:,27),100);

N=[N1' N2' N3'];
NavgC1=mean(N');
Sn=std(N');

ULC1=NavgC1+1.66*Sn;
LLC1=NavgC1-1.66*Sn;

figure(1)
subplot(3,4,9)
plot(XC1,NavgC1,'k-',XC1,ULC1,'k--',XC1,LLC1,'k--')
title('C1')

% C2=28-30

[N1,XC2]=hist(RED_B(:,28),100);
[N2,X2]=hist(RED_B(:,29),100);
[N3,X3]=hist(RED_B(:,30),100);

N=[N1' N2' N3'];
NavgC2=mean(N');
Sn=std(N');

ULC2=NavgC2+1.66*Sn;
LLC2=NavgC2-1.66*Sn;

figure(1)
subplot(3,4,10)
title('C2')
plot(XC2,NavgC2,'k-',XC2,ULC2,'k--',XC2,LLC2,'k--')
axis([])

% C3=31-33

[N1,XC3]=hist(RED_B(:,31),100);
[N2,X2]=hist(RED_B(:,32),100);
[N3,X3]=hist(RED_B(:,33),100);

N=[N1' N2' N3'];
NavgC3=mean(N');
Sn=std(N');

ULC3=NavgC3+1.66*Sn;
LLC3=NavgC3-1.66*Sn;

figure(1)
subplot(3,4,11)
title('C3')
plot(XC3,NavgC3,'k-',XC3,ULC3,'k--',XC3,LLC3,'k--')

% C4=34-36

[N1,XC4]=hist(RED_B(:,34),100);
[N2,X2]=hist(RED_B(:,35),100);
[N3,X3]=hist(RED_B(:,36),100);

N=[N1' N2' N3'];
NavgC4=mean(N');
Sn=std(N');

ULC4=NavgC4+1.66*Sn;
LLC4=NavgC4-1.66*Sn;

figure(1)
subplot(3,4,12)
title('C4')
plot(XC4,NavgC4,'k-',XC4,ULC4,'k--',XC4,LLC4,'k--')

figure(2)
subplot(1,3,3)
semilogx(XC1,NavgC1,'k-',XC2,NavgC2,'r-',XC3,NavgC3,'b-',XC4,NavgC4,'g-',XC1,ULC1,'k--',XC1,LLC1,'k--')
hold on
semilogx(XC2,ULC2,'r--',XC2,LLC2,'r--')
semilogx(XC3,ULC3,'b--',XC3,LLC3,'b--')
semilogx(XC4,ULC4,'g--',XC4,LLC4,'g--')
hold off
title('pBbA5k-sfgfp/MG1655')
legend('0�M','10�M','100�M','1000�M')
axis([10 10^5 0 500])

figure(3)
subplot(1,3,3)
semilogx(XC1,NavgC1,'k-',XC2,NavgC2,'r-',XC3,NavgC3,'b-',XC4,NavgC4,'g-')
title('pBbA5k-sfgfp/MG1655')
legend('0�M IPTG','10�M IPTG','100�M IPTG','1000�M IPTG')
axis([1 10^5 0 1000])
xlabel('Log - Red Fluoresence (AU)')
ylabel('Count')